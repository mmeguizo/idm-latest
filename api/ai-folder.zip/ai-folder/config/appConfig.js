import "dotenv/config";

export const appConfig = {
  corsConfig: {
    origin: ["*"],
    methods: ["GET", "POST"],
  },
};
